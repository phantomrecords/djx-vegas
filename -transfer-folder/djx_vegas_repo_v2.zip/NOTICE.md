# NOTICE

All files, code, text, designs, images, audio, video, and other assets contained in this repository are protected works.
Use of any content is permitted **only** under the terms described in `LICENSE.md` (Creative Commons BY‑ND 4.0).

- No redistribution of derivative works is permitted.
- Proper attribution is required for any sharing of unmodified materials.
