# DISCLAIMER (No Warranty)

All materials in this repository are provided **“AS IS”** without warranties of any kind, express or implied, including but not limited to merchantability, fitness for a particular purpose, and non‑infringement.

To the maximum extent permitted by law, the authors/owners shall not be liable for any claim, damages, or other liability arising from, out of, or in connection with the materials or the use or other dealings in the materials.
