# STOLEN CONTENT WARNING

If you obtained content from this repository and have not complied with the terms in `LICENSE.md`, you are in violation of the license and applicable intellectual‑property laws.

**Remediation steps:**
1. Cease distribution and remove all copies in your control.
2. If you shared unmodified content with attribution, ensure the attribution is accurate and includes a link to the CC BY‑ND 4.0 license.
3. If you created derivative works, you **may not** distribute them. Remove them from all channels.
